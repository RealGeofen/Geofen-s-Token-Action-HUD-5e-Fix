# Geofen’s : Token Action HUD 5e Fix

A non-destructive stability patch for **Token Action HUD Core** + **Token Action HUD D&D 5e** on Foundry VTT v14 / D&D5e 5.x.

## What it fixes

- Coalesces rapid Actor, Item, Active Effect, Token, and Combat updates into a single HUD refresh.
- Detects when a HUD render started for one token but completed after the player selected another token.
- Detects an older render completing after a newer render began, then requests a clean repaint.
- Re-renders from the currently controlled token/actor after relevant changes.

## Player-setting safety

This module **does not write to** either of these settings namespaces:

- `token-action-hud-core`
- `token-action-hud-dnd5e`

It does not reset, migrate, import, export, restore, replace, or delete Token Action HUD layouts, custom groups, actions, positions, styles, or other player preferences.

The only settings it registers belong to its own namespace: `geofen-s-token-action-hud-5e-fix`.

## Requirements

- Foundry VTT v14
- D&D5e 5.1–5.x (verified target: 5.3.3)
- Token Action HUD Core 2.1.x
- Token Action HUD D&D 5e 2.1.x

## Settings

Each player may independently enable/disable the stabilization layer, enable diagnostic console logging, and adjust the refresh debounce. Defaults are safe and require no configuration.

## Diagnostics

With **Diagnostic logging** enabled, the browser console records when a stale/overtaken render is detected and why a HUD refresh was requested.

The module API is available at:

```js
game.modules.get("geofen-s-token-action-hud-5e-fix").api
```

Useful commands:

```js
game.modules.get("geofen-s-token-action-hud-5e-fix").api.status()
game.modules.get("geofen-s-token-action-hud-5e-fix").api.refresh()
```

## Release URLs

Manifest:
`https://github.com/RealGeofen/geofen-s-token-action-hud-5e-fix/releases/latest/download/module.json`

ZIP:
`https://github.com/RealGeofen/geofen-s-token-action-hud-5e-fix/releases/latest/download/geofen-s-token-action-hud-5e-fix.zip`
