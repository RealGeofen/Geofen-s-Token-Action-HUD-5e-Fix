const MODULE_ID = "geofen-s-token-action-hud-5e-fix";
const CORE_ID = "token-action-hud-core";
const DND5E_HUD_ID = "token-action-hud-dnd5e";

/**
 * Geofen’s : Token Action HUD 5e Fix
 *
 * NON-DESTRUCTIVE GUARANTEE
 * -------------------------
 * This module does not write to token-action-hud-core or token-action-hud-dnd5e
 * settings, flags, layouts, groups, actions, or persistent storage.
 *
 * It only:
 *   1. watches the currently controlled token/actor,
 *   2. coalesces bursts of document updates into a later HUD render,
 *   3. detects a HUD render that completed after the selected token changed,
 *      then requests one clean render for the current selection.
 *
 * All settings registered below belong exclusively to MODULE_ID.
 */

const state = {
  ready: false,
  refreshTimer: null,
  refreshInProgress: false,
  refreshAgain: false,
  refreshReason: null,
  selectionEpoch: 0,
  lastSelectionKey: "",
  renderPatchTarget: null,
  renderPatchOriginal: null,
  renderSequence: 0,
  lastCompletedRenderSequence: 0,
  hooksInstalled: false
};

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "enabled", {
    name: "GEOTAH5EFIX.Settings.Enabled.Name",
    hint: "GEOTAH5EFIX.Settings.Enabled.Hint",
    scope: "client",
    config: true,
    type: Boolean,
    default: true,
    requiresReload: false
  });

  game.settings.register(MODULE_ID, "diagnostics", {
    name: "GEOTAH5EFIX.Settings.Diagnostics.Name",
    hint: "GEOTAH5EFIX.Settings.Diagnostics.Hint",
    scope: "client",
    config: true,
    type: Boolean,
    default: false,
    requiresReload: false
  });

  game.settings.register(MODULE_ID, "debounceMs", {
    name: "GEOTAH5EFIX.Settings.Debounce.Name",
    hint: "GEOTAH5EFIX.Settings.Debounce.Hint",
    scope: "client",
    config: true,
    type: Number,
    default: 120,
    range: {
      min: 50,
      max: 500,
      step: 10
    },
    requiresReload: false
  });
});

Hooks.once("ready", () => {
  if (game.system.id !== "dnd5e") return;

  const core = game.modules.get(CORE_ID);
  const dnd5eHud = game.modules.get(DND5E_HUD_ID);

  if (!core?.active || !dnd5eHud?.active) {
    console.warn(`${MODULE_ID} | Token Action HUD Core and Token Action HUD D&D 5e must both be active.`);
    return;
  }

  state.ready = true;
  state.lastSelectionKey = getSelectionKey();
  installHooks();
  ensureRenderPatch();
  exposeApi();
  scheduleRefresh("ready", 250);

  log("Ready. Token Action HUD settings are read-only to this module.");
});

function enabled() {
  return state.ready && game.settings.get(MODULE_ID, "enabled") === true;
}

function diagnostics() {
  return game.settings.get(MODULE_ID, "diagnostics") === true;
}

function log(...args) {
  if (diagnostics()) console.log(`${MODULE_ID} |`, ...args);
}

function warn(...args) {
  if (diagnostics()) console.warn(`${MODULE_ID} |`, ...args);
}

function installHooks() {
  if (state.hooksInstalled) return;
  state.hooksInstalled = true;

  Hooks.on("controlToken", (_token, _controlled) => {
    if (!enabled()) return;

    const newKey = getSelectionKey();
    if (newKey !== state.lastSelectionKey) {
      state.selectionEpoch += 1;
      log("Selection changed", { from: state.lastSelectionKey, to: newKey, epoch: state.selectionEpoch });
      state.lastSelectionKey = newKey;
    }

    ensureRenderPatch();
    scheduleRefresh("token-selection", 80);
  });

  Hooks.on("canvasReady", () => {
    if (!enabled()) return;
    const newKey = getSelectionKey();
    if (newKey !== state.lastSelectionKey) {
      state.selectionEpoch += 1;
      state.lastSelectionKey = newKey;
    }
    ensureRenderPatch();
    scheduleRefresh("canvas-ready", 180);
  });

  Hooks.on("updateActor", (actor) => {
    if (isRelevantActor(actor)) scheduleRefresh("actor-update");
  });

  Hooks.on("createItem", (item) => {
    if (isRelevantActor(item?.parent)) scheduleRefresh("item-create");
  });

  Hooks.on("updateItem", (item) => {
    if (isRelevantActor(item?.parent)) scheduleRefresh("item-update");
  });

  Hooks.on("deleteItem", (item) => {
    if (isRelevantActor(item?.parent)) scheduleRefresh("item-delete");
  });

  Hooks.on("createActiveEffect", (effect) => {
    if (isRelevantActor(effect?.parent)) scheduleRefresh("effect-create");
  });

  Hooks.on("updateActiveEffect", (effect) => {
    if (isRelevantActor(effect?.parent)) scheduleRefresh("effect-update");
  });

  Hooks.on("deleteActiveEffect", (effect) => {
    if (isRelevantActor(effect?.parent)) scheduleRefresh("effect-delete");
  });

  Hooks.on("updateToken", (tokenDocument, changes) => {
    if (!enabled()) return;
    if (!isRelevantActor(tokenDocument?.actor)) return;

    const keys = Object.keys(changes ?? {});
    const movementOnly = keys.length > 0 && keys.every((key) => ["x", "y", "elevation", "rotation"].includes(key));
    if (!movementOnly) scheduleRefresh("token-update");
  });

  Hooks.on("updateCombat", () => {
    if (hasRelevantActor()) scheduleRefresh("combat-update", 100);
  });

  Hooks.on("createCombatant", (combatant) => {
    if (isRelevantActor(combatant?.actor)) scheduleRefresh("combatant-create", 100);
  });

  Hooks.on("deleteCombatant", (combatant) => {
    if (isRelevantActor(combatant?.actor)) scheduleRefresh("combatant-delete", 100);
  });
}

function getControlledTokens() {
  return canvas?.tokens?.controlled ?? [];
}

function getRelevantActors() {
  const actors = [];
  const seen = new Set();

  for (const token of getControlledTokens()) {
    const actor = token?.actor;
    if (actor && !seen.has(actor.uuid)) {
      seen.add(actor.uuid);
      actors.push(actor);
    }
  }

  // Token Action HUD can optionally remain visible for the user's assigned
  // character. Include it only when no token is controlled; this does not
  // inspect or modify the Core setting which controls that behavior.
  if (actors.length === 0 && game.user?.character && !seen.has(game.user.character.uuid)) {
    actors.push(game.user.character);
  }

  return actors;
}

function hasRelevantActor() {
  return getRelevantActors().length > 0;
}

function isRelevantActor(actor) {
  if (!enabled() || !actor) return false;
  return getRelevantActors().some((candidate) => candidate.uuid === actor.uuid || candidate.id === actor.id);
}

function getSelectionKey() {
  const tokens = getControlledTokens();
  if (tokens.length) {
    return tokens
      .map((token) => `${token?.document?.uuid ?? token?.id ?? "?"}:${token?.actor?.uuid ?? token?.actor?.id ?? "?"}`)
      .sort()
      .join("|");
  }

  return game.user?.character?.uuid ? `character:${game.user.character.uuid}` : "none";
}

function scheduleRefresh(reason, delayOverride = null) {
  if (!enabled()) return;

  state.refreshReason = reason;
  if (state.refreshTimer) clearTimeout(state.refreshTimer);

  const configured = Number(game.settings.get(MODULE_ID, "debounceMs"));
  const delay = Number.isFinite(delayOverride) ? delayOverride : Math.max(50, configured || 120);
  const epoch = state.selectionEpoch;
  const key = getSelectionKey();

  state.refreshTimer = setTimeout(() => {
    state.refreshTimer = null;

    // A newer selection supersedes this request. Queue one for the new actor
    // instead of allowing an old request to repaint the HUD.
    if (epoch !== state.selectionEpoch || key !== getSelectionKey()) {
      log("Discarded superseded refresh", { reason, key, current: getSelectionKey() });
      scheduleRefresh("superseded-refresh", 50);
      return;
    }

    void refreshHud(reason);
  }, delay);
}

async function refreshHud(reason) {
  if (!enabled()) return;
  ensureRenderPatch();

  if (state.refreshInProgress) {
    state.refreshAgain = true;
    state.refreshReason = reason;
    log("Coalesced refresh while another refresh is running", reason);
    return;
  }

  const hud = game.tokenActionHud;
  if (!hud || typeof hud.render !== "function") {
    warn("Token Action HUD instance is unavailable; refresh skipped.");
    return;
  }

  state.refreshInProgress = true;
  const epoch = state.selectionEpoch;
  const key = getSelectionKey();

  try {
    log("Refreshing HUD", { reason, key, epoch });
    await callHudRender(hud);
  } catch (error) {
    console.error(`${MODULE_ID} | HUD refresh failed`, error);
  } finally {
    state.refreshInProgress = false;

    if (epoch !== state.selectionEpoch || key !== getSelectionKey()) {
      state.refreshAgain = true;
      state.refreshReason = "selection-changed-during-refresh";
    }

    if (state.refreshAgain) {
      const nextReason = state.refreshReason ?? "queued-refresh";
      state.refreshAgain = false;
      scheduleRefresh(nextReason, 50);
    }
  }
}

async function callHudRender(hud) {
  const AppV2 = foundry?.applications?.api?.ApplicationV2;
  let result;

  // Foundry v14's ApplicationV2 uses an options object. Keep a fallback for
  // unusual wrappers without assuming Token Action HUD's implementation.
  if (AppV2 && hud instanceof AppV2) {
    result = hud.render({ force: true });
  } else {
    result = hud.render(true);
  }

  if (result && typeof result.then === "function") await result;
}

/**
 * Wrap only the live HUD instance's render method. The wrapper never changes
 * render arguments or return values. It observes start/finish ordering and,
 * when an older render finishes after the token selection has changed (or
 * after a newer render has started), requests one authoritative repaint.
 */
function ensureRenderPatch() {
  if (!state.ready) return;

  const hud = game.tokenActionHud;
  if (!hud || typeof hud.render !== "function") return;
  if (state.renderPatchTarget === hud && hud.render?.__geofenTah5eFix === true) return;

  const original = hud.render;
  if (original?.__geofenTah5eFix === true) {
    state.renderPatchTarget = hud;
    return;
  }

  const wrapped = function (...args) {
    const sequence = ++state.renderSequence;
    const startKey = getSelectionKey();
    const startEpoch = state.selectionEpoch;

    let result;
    try {
      result = original.apply(this, args);
    } catch (error) {
      throw error;
    }

    Promise.resolve(result).then(
      () => handleRenderComplete(sequence, startKey, startEpoch),
      () => handleRenderComplete(sequence, startKey, startEpoch)
    );

    // Preserve Token Action HUD's exact render return contract.
    return result;
  };

  Object.defineProperty(wrapped, "__geofenTah5eFix", {
    value: true,
    enumerable: false,
    configurable: false,
    writable: false
  });

  state.renderPatchTarget = hud;
  state.renderPatchOriginal = original;
  hud.render = wrapped;
  log("Installed stale-render detector on the live HUD instance.");
}

function handleRenderComplete(sequence, startKey, startEpoch) {
  if (!enabled()) return;

  const currentKey = getSelectionKey();
  const staleSelection = startEpoch !== state.selectionEpoch || startKey !== currentKey;
  const overtaken = sequence < state.renderSequence;

  state.lastCompletedRenderSequence = Math.max(state.lastCompletedRenderSequence, sequence);

  if (staleSelection || overtaken) {
    log("Detected stale/overtaken HUD render", {
      sequence,
      newestSequence: state.renderSequence,
      startKey,
      currentKey,
      staleSelection,
      overtaken
    });
    scheduleRefresh("stale-render-detected", 50);
  }
}

function exposeApi() {
  const module = game.modules.get(MODULE_ID);
  if (!module) return;

  module.api = Object.freeze({
    /** Request a non-destructive HUD repaint. */
    refresh: () => scheduleRefresh("manual-api", 0),

    /** Current diagnostic state; contains no player layout data. */
    status: () => ({
      enabled: enabled(),
      selectionKey: getSelectionKey(),
      selectionEpoch: state.selectionEpoch,
      refreshInProgress: state.refreshInProgress,
      renderSequence: state.renderSequence,
      coreVersion: game.modules.get(CORE_ID)?.version ?? null,
      dnd5eHudVersion: game.modules.get(DND5E_HUD_ID)?.version ?? null,
      systemVersion: game.system.version,
      foundryVersion: game.version
    }),

    /**
     * Safety declaration for troubleshooting. These are the namespaces this
     * module intentionally treats as read-only.
     */
    protectedNamespaces: Object.freeze([CORE_ID, DND5E_HUD_ID])
  });
}
